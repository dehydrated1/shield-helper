package com.example.shieldhelper.client;

import com.example.shieldhelper.ShieldHelperMod;
import com.example.shieldhelper.config.ShieldHelperConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import it.unimi.dsi.fastutil.objects.Object2IntMap;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

@Environment(EnvType.CLIENT)
public final class ShieldDisableTrigger {
    private static final int SUCCESS_CHECK_DELAY_MILLIS = 100;
    private static final class_2350[] WEB_PLACEMENT_DIRECTIONS = {
            class_2350.field_11036,
            class_2350.field_11043,
            class_2350.field_11035,
            class_2350.field_11039,
            class_2350.field_11034,
            class_2350.field_11033
    };

    private static int triggerCooldownTicks;
    private static boolean sequenceInProgress;
    private static long currentSequenceId;
    private static boolean isMacroAttacking;
    private static boolean toggleKeyWasDown;

    public static boolean isSequenceInProgress() {
        return sequenceInProgress;
    }

    private static int getPingAdjustedMillis(class_310 client, int baseDelayMillis) {
        if (ShieldHelperConfig.get().blatantMode) {
            return 0;
        }
        int delay = baseDelayMillis;
        if (ShieldHelperConfig.get().pingCompensation && client.method_1562() != null && client.field_1724 != null) {
            net.minecraft.class_640 playerInfo = client.method_1562().method_2871(client.field_1724.method_5667());
            if (playerInfo != null) {
                delay += (playerInfo.method_2959() / 2);
            }
        }
        return delay;
    }

    private static void triggerPostAttackGuard(class_310 client, int guardTicks) {
        class_746 player = client.field_1724;
        if (player == null || !player.method_6079().method_31574(class_1802.field_8255)) {
            return;
        }

        if (client.field_1690 != null && client.field_1690.field_1904 != null) {
            client.field_1690.field_1904.method_23481(true);
            scheduleAsync(client, guardTicks * 50, () -> {
                if (client.field_1690 != null && client.field_1690.field_1904 != null) {
                    client.field_1690.field_1904.method_23481(false);
                }
            });
        }
    }

    private ShieldDisableTrigger() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(ShieldDisableTrigger::tick);
        ClientPreAttackCallback.EVENT.register(ShieldDisableTrigger::onPreAttack);
        AttackEntityCallback.EVENT.register(ShieldDisableTrigger::onAttackEntity);
    }

    private static void tick(class_310 client) {
        if (triggerCooldownTicks > 0) {
            triggerCooldownTicks--;
        }

        ShieldHelperConfig config = ShieldHelperConfig.get();
        handleMacroToggleHotkey(client, config);
    }

    private static boolean onPreAttack(class_310 client, class_746 player, int clickCount) {
        if (sequenceInProgress) {
            return true;
        }

        // Trigger on any attack attempt (click or hold) if the target is blocking
        return tryStartSequence(client, player, getCrosshairEntity(client));
    }

    private static class_1269 onAttackEntity(class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, class_3966 hitResult) {
        class_310 client = class_310.method_1551();
        if (!(player instanceof class_746 localPlayer) || player != client.field_1724 || level != client.field_1687) {
            return class_1269.field_5811;
        }

        if (isMacroAttacking || sequenceInProgress) {
            return class_1269.field_5811;
        }

        return tryStartSequence(client, localPlayer, entity) ? class_1269.field_5814 : class_1269.field_5811;
    }

    private static boolean tryStartSequence(class_310 client, class_746 player, class_1297 target) {
        ShieldHelperConfig config = ShieldHelperConfig.get();
        if (!config.enabled || sequenceInProgress || triggerCooldownTicks > 0) {
            return false;
        }

        if (!ShieldHelperSafety.isActionAllowed(client, config)) {
            return false;
        }

        if (client.field_1755 != null || player == null || client.field_1687 == null || client.field_1761 == null) {
            return false;
        }

        if (!client.field_1761.method_2908()) {
            return false;
        }

        if (isShieldBlocking(player)) {
            return false;
        }

        if (!(target instanceof class_1657 targetPlayer) || targetPlayer == player || !targetPlayer.method_5805() || !targetPlayer.method_5732() || !targetPlayer.method_5863()) {
            return false;
        }

        if (!isReachableEntity(player, targetPlayer)) {
            return false;
        }

        if (!isShieldEffectivelyBlocking(player, targetPlayer)) {
            return false;
        }

        if (!config.blatantMode && config.requireAttackCooldown && player.method_7261(0.0F) * 100.0F < config.minimumAttackStrengthPercent) {
            return false;
        }

        int axeSlot = findHotbarAxe(player.method_31548());
        if (axeSlot == class_1661.field_30640) {
            return false;
        }

        // Anti-suspicion: Roll shield disable miss chance
        if (config.shieldMissChancePercent > 0 && ThreadLocalRandom.current().nextInt(100) < config.shieldMissChancePercent) {
            triggerCooldownTicks = ShieldHelperConfig.get().blatantMode ? 0 : config.attackCooldownTicks;
            return false;
        }

        int previousSlot = player.method_31548().method_67532();
        TriggerSettings settings = TriggerSettings.from(config);
        
        // Sequence initialization with unique tracking ID
        currentSequenceId++;
        long seqId = currentSequenceId;
        sequenceInProgress = true;
        
        int swapDelay = getPingAdjustedMillis(client, config.swapDelayMillis);
        if (config.blatantMode || swapDelay <= 0) {
            swapToAxe(client, targetPlayer, previousSlot, axeSlot, settings, seqId);
        } else {
            scheduleAsync(client, swapDelay, () -> swapToAxe(client, targetPlayer, previousSlot, axeSlot, settings, seqId));
        }
        return true;
    }

    private static void handleMacroToggleHotkey(class_310 client, ShieldHelperConfig config) {
        if (!config.hotkeyToggleEnabled || client.field_1755 != null) {
            toggleKeyWasDown = false;
            return;
        }

        boolean toggleKeyDown = class_3675.method_15987(client.method_22683(), config.toggleKeyCode);
        if (toggleKeyDown && !toggleKeyWasDown) {
            config.enabled = !config.enabled;
            ShieldHelperConfig.save();
            sendMacroStatusMessage(client, config);
        }

        toggleKeyWasDown = toggleKeyDown;
    }

    private static void sendMacroStatusMessage(class_310 client, ShieldHelperConfig config) {
        if (!config.statusNotifications || client.field_1724 == null) {
            return;
        }

        if (!config.enabled) {
            client.field_1724.method_7353(class_2561.method_43471("shield-helper.message.macro_off"), true);
            return;
        }

        client.field_1724.method_7353(class_2561.method_43471(ShieldHelperSafety.isActionAllowed(client, config)
                ? "shield-helper.message.macro_on"
                : "shield-helper.message.macro_blocked"), true);
    }

    private static void swapToAxe(class_310 client, class_1657 target, int previousSlot, int axeSlot, TriggerSettings settings, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        class_746 player = client.field_1724;
        if (!canContinue(client, target, true) || player == null || !isAxeInSlot(player.method_31548(), axeSlot)) {
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
            return;
        }

        boolean swapped = false;
        if (player.method_31548().method_67532() != axeSlot) {
            if (!selectSlot(player, axeSlot)) {
                finishSequence(client, previousSlot, axeSlot, settings, seqId);
                return;
            }
            swapped = true;
        }

        int firstAttackDelay = getPingAdjustedMillis(client, settings.firstAttackDelayMillis());
        if (swapped) {
            firstAttackDelay = Math.max(20, firstAttackDelay); // Safe sub-tick buffer after swap
        }
        
        if (ShieldHelperConfig.get().blatantMode || firstAttackDelay <= 0) {
            performFirstAttack(client, target, previousSlot, axeSlot, settings, seqId);
        } else {
            scheduleAsync(client, firstAttackDelay, () -> performFirstAttack(client, target, previousSlot, axeSlot, settings, seqId));
        }
    }

    private static void performFirstAttack(class_310 client, class_1657 target, int previousSlot, int axeSlot, TriggerSettings settings, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        class_746 player = client.field_1724;
        if (!canContinue(client, target, true) || player == null || !isAxeInSlot(player.method_31548(), axeSlot)) {
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
            return;
        }

        if (player.method_31548().method_67532() != axeSlot && !selectSlot(player, axeSlot)) {
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
            return;
        }

        isMacroAttacking = true;
        client.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
        isMacroAttacking = false;
        
        triggerCooldownTicks = ShieldHelperConfig.get().blatantMode ? 0 : settings.attackCooldownTicks();
        scheduleAsync(client, SUCCESS_CHECK_DELAY_MILLIS, () -> recordDisableResult(client, target, seqId));

        if (settings.stunning()) {
            int stunDelayMillis = ThreadLocalRandom.current().nextInt(settings.stunningMinDelayMillis(), settings.stunningMaxDelayMillis() + 1);
            int pingAdjustedDelay = getPingAdjustedMillis(client, stunDelayMillis);
            if (ShieldHelperConfig.get().blatantMode || pingAdjustedDelay <= 0) {
                performStunClick(client, target, previousSlot, axeSlot, settings, seqId);
            } else {
                scheduleAsync(client, pingAdjustedDelay, () -> performStunClick(client, target, previousSlot, axeSlot, settings, seqId));
            }
        } else {
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
        }
    }

    private static void recordDisableResult(class_310 client, class_1657 target, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        boolean success = target.method_31481()
                || !target.method_5805()
                || target.method_73183() == client.field_1687 && !isShieldBlocking(target);
        ShieldHelperConfig.get().recordShieldDisableResult(success);
        ShieldHelperConfig.save();
    }

    private static void performStunClick(class_310 client, class_1657 target, int previousSlot, int axeSlot, TriggerSettings settings, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        
        // Anti-suspicion: Roll miss chance for the extra click
        if (settings.missChancePercent() > 0 && ThreadLocalRandom.current().nextInt(100) < settings.missChancePercent()) {
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
            return;
        }

        class_746 player = client.field_1724;
        int stunSlot = getStunSlot(player, axeSlot, settings);
        if (!canContinue(client, target, false) || player == null || stunSlot == class_1661.field_30640) {
            if (previousSlot != axeSlot) selectSlotSilent(client.field_1724, previousSlot);
            finishSequence(client, previousSlot, axeSlot, settings, seqId);
            return;
        }

        executeStunAttack(client, target, previousSlot, axeSlot, stunSlot, settings, seqId);
    }

    private static void executeStunAttack(class_310 client, class_1657 target, int previousSlot, int axeSlot, int stunSlot, TriggerSettings settings, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        class_746 player = client.field_1724;
        if (!canContinue(client, target, false) || player == null) {
            if (previousSlot != stunSlot) selectSlotSilent(player, previousSlot);
            finishSequence(client, previousSlot, stunSlot, settings, seqId);
            return;
        }

        boolean swapped = (previousSlot != stunSlot);
        if (swapped) {
            selectSlotSilent(player, stunSlot);
        }

        isMacroAttacking = true;
        client.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
        isMacroAttacking = false;

        if (swapped) {
            selectSlotSilent(player, previousSlot);
        }

        boolean forceSwitchBack = settings.smpProfile() && settings.stunning();
        if (settings.stunWeb() != ShieldHelperConfig.StunWebMode.OFF) {
            class_2338 webPos = class_2338.method_49637(target.method_23317(), target.method_23318(), target.method_23321()).method_10062();
            int webDelay = getPingAdjustedMillis(client, settings.stunWebDelayMillis());
            if (ShieldHelperConfig.get().blatantMode || webDelay <= 0) {
                performStunWeb(client, target, webPos, previousSlot, stunSlot, settings, forceSwitchBack, seqId);
            } else {
                scheduleAsync(client, webDelay, () -> performStunWeb(client, target, webPos, previousSlot, stunSlot, settings, forceSwitchBack, seqId));
            }
        } else {
            finishSequence(client, previousSlot, stunSlot, settings, forceSwitchBack, seqId);
        }
    }

    private static void performStunWeb(class_310 client, class_1657 target, class_2338 webPos, int previousSlot, int currentSlot, TriggerSettings settings, boolean forceSwitchBack, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        class_746 player = client.field_1724;
        int webSlot = player == null ? class_1661.field_30640 : findHotbarCobweb(player.method_31548());
        if (!canContinueForWeb(client, target) || player == null || webSlot == class_1661.field_30640 || !isCobwebInSlot(player.method_31548(), webSlot)) {
            finishSequence(client, previousSlot, currentSlot, settings, forceSwitchBack, seqId);
            return;
        }

        class_3965 hitResult = findWebPlacementHit(client, webPos);
        if (hitResult == null) {
            finishSequence(client, previousSlot, currentSlot, settings, forceSwitchBack, seqId);
            return;
        }

        executeWebPlacement(client, target, hitResult, previousSlot, webSlot, settings, seqId);
    }

    private static void executeWebPlacement(class_310 client, class_1657 target, class_3965 hitResult, int previousSlot, int webSlot, TriggerSettings settings, long seqId) {
        if (seqId != currentSequenceId || !sequenceInProgress) return;
        class_746 player = client.field_1724;
        if (!canContinueForWeb(client, target) || player == null || !isCobwebInSlot(player.method_31548(), webSlot)) {
            finishSequence(client, previousSlot, webSlot, settings, true, seqId);
            return;
        }

        if (!isReachableBlockHit(player, hitResult)) {
            finishSequence(client, previousSlot, webSlot, settings, true, seqId);
            return;
        }

        boolean swapped = (previousSlot != webSlot);
        if (swapped) {
            selectSlotSilent(player, webSlot);
        }

        if (ShieldHelperConfig.get().blatantMode) {
            Rotation rot = rotationTo(player.method_33571(), hitResult.method_17784());
            player.method_36456(rot.yRot());
            player.method_36457(rot.xRot());
            player.field_3944.method_52787(new class_2828.class_2831(rot.yRot(), rot.xRot(), player.method_24828(), player.field_5976));
        }

        client.field_1761.method_2896(player, class_1268.field_5808, hitResult);
        player.method_6104(class_1268.field_5808);

        if (swapped) {
            selectSlotSilent(player, previousSlot);
        }

        finishSequence(client, previousSlot, webSlot, settings, true, seqId);
    }

    private static void finishSequence(class_310 client, int previousSlot, int axeSlot, TriggerSettings settings, long seqId) {
        finishSequence(client, previousSlot, axeSlot, settings, false, seqId);
    }

    private static void finishSequence(class_310 client, int previousSlot, int axeSlot, TriggerSettings settings, boolean forceSwitchBack, long seqId) {
        if (seqId != currentSequenceId) return;

        try {
            if ((settings.switchBackAfterAttack() || forceSwitchBack) && previousSlot != axeSlot) {
                int switchBackDelay = getPingAdjustedMillis(client, settings.switchBackDelayMillis());
                if (ShieldHelperConfig.get().blatantMode && switchBackDelay <= 0) {
                    switchBackDelay = 15; // Safe minimum delay in blatant mode
                }
                if (switchBackDelay <= 0) {
                    try {
                        class_746 player = client.field_1724;
                        if (player != null && player.method_31548().method_67532() == axeSlot) {
                            selectSlot(player, previousSlot);
                            if (settings.postAttackGuard()) {
                                triggerPostAttackGuard(client, settings.postAttackGuardTicks());
                            }
                        }
                    } finally {
                        sequenceInProgress = false;
                    }
                } else {
                    scheduleAsync(client, switchBackDelay, () -> {
                        if (seqId != currentSequenceId) return;
                        try {
                            class_746 player = client.field_1724;
                            if (player != null && player.method_31548().method_67532() == axeSlot) {
                                selectSlot(player, previousSlot);
                                if (settings.postAttackGuard()) {
                                    triggerPostAttackGuard(client, settings.postAttackGuardTicks());
                                }
                            }
                        } finally {
                            sequenceInProgress = false;
                        }
                    });
                }
            } else {
                sequenceInProgress = false;
                if (settings.postAttackGuard()) {
                    triggerPostAttackGuard(client, settings.postAttackGuardTicks());
                }
            }
        } catch (Exception e) {
            sequenceInProgress = false;
        }
    }

    private static void scheduleAsync(class_310 client, int delayMillis, Runnable action) {
        CompletableFuture.runAsync(
                () -> client.execute(action),
                CompletableFuture.delayedExecutor(Math.max(1, delayMillis), TimeUnit.MILLISECONDS)
        );
    }

    private static boolean canContinue(class_310 client, class_1657 target, boolean requireShieldBlocking) {
        ShieldHelperConfig config = ShieldHelperConfig.get();
        if (!config.enabled || !ShieldHelperSafety.isActionAllowed(client, config) || client.field_1755 != null || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null || !client.field_1761.method_2908()) {
            return false;
        }

        if (isShieldBlocking(client.field_1724)) {
            return false;
        }

        if (target.method_31481() || !target.method_5805() || !target.method_5732() || !target.method_5863() || target.method_73183() != client.field_1687) {
            return false;
        }

        if (!isReachableEntity(client.field_1724, target)) {
            return false;
        }

        if (!ShieldHelperConfig.get().blatantMode && !isAimingAtEntity(client, client.field_1724, target)) {
            return false;
        }

        return !requireShieldBlocking || isShieldEffectivelyBlocking(client.field_1724, target);
    }

    private static boolean isShieldEffectivelyBlocking(class_1657 attacker, class_1657 target) {
        if (!isShieldBlocking(target)) {
            return false;
        }

        class_243 attackerPos = attacker.method_73189();
        class_243 targetPos = target.method_73189();
        class_243 directionToAttacker = attackerPos.method_1020(targetPos).method_1029();
        class_243 targetLook = target.method_5828(1.0F);

        // Vanilla check: Dot product > 0 means the attacker is in the front 180-degree arc of the target
        return targetLook.method_1026(directionToAttacker) > 0;
    }

    private static boolean canContinueForWeb(class_310 client, class_1657 target) {
        ShieldHelperConfig config = ShieldHelperConfig.get();
        if (!config.enabled || !ShieldHelperSafety.isActionAllowed(client, config) || client.field_1755 != null || client.field_1724 == null || client.field_1687 == null || client.field_1761 == null || !client.field_1761.method_2908()) {
            return false;
        }

        if (isShieldBlocking(client.field_1724)) {
            return false;
        }

        return !target.method_31481() && target.method_5805() && target.method_73183() == client.field_1687;
    }

    private static class_3965 findWebPlacementHit(class_310 client, class_2338 webPos) {
        if (client.field_1687 == null || client.field_1724 == null) {
            return null;
        }

        if (!canPlaceCobwebAt(client, webPos)) {
            return null;
        }

        if (client.field_1765 instanceof class_3965 blockHitResult
                && blockHitResult.method_17783() == class_239.class_240.field_1332
                && isValidWebPlacementHit(client, blockHitResult, webPos)) {
            return blockHitResult;
        }

        if (ShieldHelperConfig.get().blatantMode) {
            return findBlatantWebPlacementHit(client, webPos);
        }

        return null;
    }

    private static boolean canPlaceCobwebAt(class_310 client, class_2338 webPos) {
        if (!client.field_1687.method_24794(webPos) || !client.field_1687.method_8477(webPos) || !client.field_1687.method_8505(client.field_1724, webPos)) {
            return false;
        }

        class_2680 placementState = client.field_1687.method_8320(webPos);
        return !placementState.method_27852(class_2246.field_10343) && placementState.method_45474();
    }

    private static boolean isValidWebPlacementHit(class_310 client, class_3965 hitResult, class_2338 webPos) {
        if (!canPlaceCobwebAt(client, webPos)) {
            return false;
        }

        class_2338 clickedPos = hitResult.method_17777();
        if (!client.field_1687.method_24794(clickedPos) || !client.field_1687.method_8477(clickedPos)) {
            return false;
        }

        class_2680 clickedState = client.field_1687.method_8320(clickedPos);
        class_2338 expectedPlacementPos = clickedState.method_45474() ? clickedPos : clickedPos.method_10093(hitResult.method_17780());
        if (!expectedPlacementPos.equals(webPos)) {
            return false;
        }

        if (!clickedState.method_45474() && clickedState.method_26215()) {
            return false;
        }

        return isReachableBlockHit(client.field_1724, hitResult);
    }

    private static boolean isReachableBlockHit(class_746 player, class_3965 hitResult) {
        if (player == null) return false;
        double interactionRange = player.method_55754();
        // GHOST: Hardened Legitimacy - Subtract a tiny epsilon (0.05) to ensure we are comfortably within vanilla range
        double maxDist = interactionRange - 0.05;
        return player.method_33571().method_1025(hitResult.method_17784()) <= maxDist * maxDist;
    }

    private static boolean isReachableEntity(class_746 player, class_1297 target) {
        if (player == null || target == null) return false;
        double interactionRange = player.method_55755();
        double maxAttackRange = ShieldHelperConfig.get().maxAttackRange;
        double maxDist = Math.min(interactionRange, maxAttackRange) - 0.05;
        return target.method_5829().method_49271(player.method_33571()) <= maxDist * maxDist;
    }

    private static boolean isAimingAtEntity(class_310 client, class_746 player, class_1297 target) {
        double interactionRange = player.method_55755();
        class_243 eyePosition = player.method_33571();
        class_243 lookVector = player.method_5828(1.0F);
        class_243 lookEnd = eyePosition.method_1019(lookVector.method_1021(interactionRange));
        
        Optional<class_243> entityHit = target.method_5829().method_1014(target.method_5871()).method_992(eyePosition, lookEnd);
        if (entityHit.isEmpty()) {
            return false;
        }

        double entityHitDistance = eyePosition.method_1025(entityHit.get());
        class_3965 blockHit = client.field_1687.method_17742(new class_3959(
                eyePosition,
                entityHit.get(),
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                player
        ));

        return blockHit.method_17783() != class_239.class_240.field_1332
                || eyePosition.method_1025(blockHit.method_17784()) + 1.0E-5D >= entityHitDistance;
    }

    private static class_1297 getCrosshairEntity(class_310 client) {
        if (client.field_1765 instanceof class_3966 entityHitResult) {
            return entityHitResult.method_17782();
        }

        return null;
    }

    private static boolean isShieldBlocking(class_1657 player) {
        return player.method_6039() && player.method_6030().method_31574(class_1802.field_8255);
    }

    private static int findHotbarAxe(class_1661 inventory) {
        for (int slot = 0; slot < class_1661.method_7368(); slot++) {
            if (isAxeInSlot(inventory, slot)) {
                return slot;
            }
        }

        return class_1661.field_30640;
    }

    private static int getStunSlot(class_746 player, int axeSlot, TriggerSettings settings) {
        if (player == null) {
            return class_1661.field_30640;
        }

        if (!settings.smpProfile()) {
            return isAxeInSlot(player.method_31548(), axeSlot) ? axeSlot : class_1661.field_30640;
        }

        int knockbackSwordSlot = findHotbarKnockbackOneSword(player.method_31548());
        return knockbackSwordSlot == class_1661.field_30640 ? findHotbarSword(player.method_31548()) : knockbackSwordSlot;
    }

    private static int findHotbarKnockbackOneSword(class_1661 inventory) {
        for (int slot = 0; slot < class_1661.method_7368(); slot++) {
            if (isKnockbackOneSword(inventory, slot)) {
                return slot;
            }
        }

        return class_1661.field_30640;
    }

    private static int findHotbarSword(class_1661 inventory) {
        for (int slot = 0; slot < class_1661.method_7368(); slot++) {
            if (isSwordInSlot(inventory, slot)) {
                return slot;
            }
        }

        return class_1661.field_30640;
    }

    private static int findHotbarCobweb(class_1661 inventory) {
        for (int slot = 0; slot < class_1661.method_7368(); slot++) {
            if (isCobwebInSlot(inventory, slot)) {
                return slot;
            }
        }

        return class_1661.field_30640;
    }

    private static boolean isAxeInSlot(class_1661 inventory, int slot) {
        return class_1661.method_7380(slot) && inventory.method_5438(slot).method_31573(class_3489.field_42612);
    }

    private static boolean isSwordInSlot(class_1661 inventory, int slot) {
        return class_1661.method_7380(slot) && inventory.method_5438(slot).method_31573(class_3489.field_42611);
    }

    private static boolean isCobwebInSlot(class_1661 inventory, int slot) {
        return class_1661.method_7380(slot) && inventory.method_5438(slot).method_31574(class_1802.field_8786);
    }

    private static boolean isKnockbackOneSword(class_1661 inventory, int slot) {
        if (!isSwordInSlot(inventory, slot)) {
            return false;
        }

        for (Object2IntMap.Entry<class_6880<class_1887>> entry : inventory.method_5438(slot).method_58657().method_57539()) {
            if (entry.getKey().method_40225(class_1893.field_9121) && entry.getIntValue() == 1) {
                return true;
            }
        }

        return false;
    }

    private static boolean selectSlot(class_746 player, int slot) {
        if (player == null || !class_1661.method_7380(slot)) {
            return false;
        }

        // GHOST: Redundant check to avoid unnecessary packets
        if (player.method_31548().method_67532() == slot) {
            return true;
        }

        player.method_31548().method_61496(slot);
        player.field_3944.method_52787(new class_2868(slot));
        return true;
    }

    private static boolean selectSlotSilent(class_746 player, int slot) {
        if (player == null || !class_1661.method_7380(slot)) {
            return false;
        }
        player.field_3944.method_52787(new class_2868(slot));
        return true;
    }

    private record TriggerSettings(
            boolean switchBackAfterAttack,
            boolean stunning,
            ShieldHelperConfig.StunWebMode stunWeb,
            boolean smpProfile,
            int attackCooldownTicks,
            int firstAttackDelayMillis,
            int stunningMinDelayMillis,
            int stunningMaxDelayMillis,
            int stunWebDelayMillis,
            int switchBackDelayMillis,
            boolean postAttackGuard,
            int postAttackGuardTicks,
            int missChancePercent,
            int shieldMissChancePercent
    ) {
        private static TriggerSettings from(ShieldHelperConfig config) {
            return new TriggerSettings(
                    config.switchBackAfterAttack,
                    config.stunning,
                    config.stunning ? config.stunWeb : ShieldHelperConfig.StunWebMode.OFF,
                    ShieldHelperConfig.PROFILE_SMP.equals(config.combatProfile),
                    config.attackCooldownTicks,
                    config.firstAttackDelayMillis,
                    Math.min(config.stunningMinDelayMillis, config.stunningMaxDelayMillis),
                    Math.max(config.stunningMinDelayMillis, config.stunningMaxDelayMillis),
                    config.stunWebDelayMillis,
                    config.switchBackDelayMillis,
                    config.postAttackGuard,
                    config.postAttackGuardTicks,
                    config.missChancePercent,
                    config.shieldMissChancePercent
            );
        }
    }

    private static class_3965 findBlatantWebPlacementHit(class_310 client, class_2338 webPos) {
        class_746 player = client.field_1724;
        if (player == null) return null;

        for (class_2350 direction : WEB_PLACEMENT_DIRECTIONS) {
            class_2338 clickedPos = webPos.method_10093(direction.method_10153());
            if (!client.field_1687.method_24794(clickedPos) || !client.field_1687.method_8477(clickedPos)) {
                continue;
            }

            class_2680 clickedState = client.field_1687.method_8320(clickedPos);
            if (clickedState.method_45474() || clickedState.method_26215()) {
                continue;
            }

            class_243 hitLocation = class_243.method_24953(clickedPos).method_1031(
                    direction.method_10148() * 0.5D,
                    direction.method_10164() * 0.5D,
                    direction.method_10165() * 0.5D
            );
            class_3965 hitResult = new class_3965(hitLocation, direction, clickedPos, false);
            if (isValidWebPlacementHit(client, hitResult, webPos)) {
                return hitResult;
            }
        }

        return null;
    }

    private record Rotation(float yRot, float xRot) {}

    private static Rotation rotationTo(class_243 from, class_243 to) {
        class_243 delta = to.method_1020(from);
        double horizontalDistance = Math.sqrt(delta.field_1352 * delta.field_1352 + delta.field_1350 * delta.field_1350);
        float yRot = (float) (Math.toDegrees(Math.atan2(delta.field_1350, delta.field_1352)) - 90.0D);
        float xRot = (float) -Math.toDegrees(Math.atan2(delta.field_1351, horizontalDistance));
        return new Rotation(yRot, xRot);
    }
}

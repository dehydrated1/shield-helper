package com.example.shieldhelper.client;

import com.example.shieldhelper.config.ShieldHelperConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

@Environment(EnvType.CLIENT)
public final class ShieldHelperConfigScreen extends class_437 {

    private static final int PAGE_GENERAL = 0;
    private static final int PAGE_CONTROLS = 1;
    private static final int PAGE_DELAYS = 2;
    private static final int CONTROL_WIDTH = 220;
    private static final int CONTROL_HEIGHT = 20;
    private static final int CONTROL_SPACING = 20;
    private static final int DELAY_MAX_MILLIS = 250;
    private static final int DELAY_STEP_MILLIS = 5;

    private final class_437 parent;
    private final ShieldHelperConfig config;

    private int page = PAGE_GENERAL;
    private boolean waitingForToggleKey;

    private class_4185 generalPageButton;
    private class_4185 controlsPageButton;
    private class_4185 delaysPageButton;

    private class_4185 profileButton;
    private class_4185 enabledButton;
    private class_4185 hotkeyToggleButton;
    private class_4185 statusNotificationsButton;
    private class_4185 toggleKeyButton;
    private class_4185 safetyModeButton;
    private class_4185 safetyStatusButton;
    private class_4185 trustedServerButton;

    private class_4185 switchBackButton;
    private class_4185 stunningButton;
    private class_4185 missChanceButton;
    private class_4185 shieldMissChanceButton;
    private class_4185 stunWebButton;
    private class_4185 cooldownRequirementButton;
    private class_4185 attackStrengthButton;
    private class_4185 triggerCooldownButton;
    private class_4185 pingCompensationButton;
    private class_4185 maxAttackRangeButton;
    private class_4185 postAttackGuardButton;
    private class_4185 postAttackGuardTicksButton;
    private class_4185 blatantModeButton;

    private DelaySliderButton swapDelaySlider;
    private DelaySliderButton firstAttackDelaySlider;
    private DelaySliderButton stunningMinDelaySlider;
    private DelaySliderButton stunningMaxDelaySlider;
    private DelaySliderButton stunWebDelaySlider;
    private DelaySliderButton switchBackDelaySlider;

    public ShieldHelperConfigScreen(class_437 parent) {
        super(class_2561.method_43471("shield-helper.config.title"));
        this.parent = parent;
        this.config = ShieldHelperConfig.get();
    }

    @Override
    protected void method_25426() {
        buildWidgets();
    }

    private void buildWidgets() {
        method_37067();

        int x = (this.field_22789 - CONTROL_WIDTH) / 2;
        int tabY = 44;
        int tabWidth = (CONTROL_WIDTH - 12) / 3;

        generalPageButton = method_37063(class_4185.method_46430(generalPageText(), button -> {
            page = PAGE_GENERAL;
            waitingForToggleKey = false;
            buildWidgets();
        }).method_46434(x, tabY, tabWidth, CONTROL_HEIGHT).method_46431());

        controlsPageButton = method_37063(class_4185.method_46430(controlsPageText(), button -> {
            page = PAGE_CONTROLS;
            waitingForToggleKey = false;
            buildWidgets();
        }).method_46434(x + tabWidth + 6, tabY, tabWidth, CONTROL_HEIGHT).method_46431());

        delaysPageButton = method_37063(class_4185.method_46430(delaysPageText(), button -> {
            page = PAGE_DELAYS;
            waitingForToggleKey = false;
            buildWidgets();
        }).method_46434(x + (tabWidth + 6) * 2, tabY, tabWidth, CONTROL_HEIGHT).method_46431());

        int y = tabY + CONTROL_SPACING + 4;
        if (page == PAGE_DELAYS) {
            addDelayControls(x, y);
        } else if (page == PAGE_CONTROLS) {
            addControlControls(x, y);
        } else {
            addGeneralControls(x, y);
        }

        int bottomY = this.field_22790 - 28;
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> this.method_25419())
                .method_46434(x, bottomY, CONTROL_WIDTH / 2 - 2, CONTROL_HEIGHT).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43471("shield-helper.config.reset"), button -> {
            config.reset();
            ShieldHelperConfig.save();
            buildWidgets();
        }).method_46434(x + CONTROL_WIDTH / 2 + 2, bottomY, CONTROL_WIDTH / 2 - 2, CONTROL_HEIGHT).method_46431());
    }

    private void addGeneralControls(int x, int y) {
        int offset = 0;

        profileButton = method_37063(class_4185.method_46430(profileText(), button -> {
            config.cycleCombatProfile();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        shieldMissChanceButton = method_37063(class_4185.method_46430(shieldMissChanceText(), button -> {
            config.cycleShieldMissChance();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        switchBackButton = method_37063(class_4185.method_46430(switchBackText(), button -> {
            config.switchBackAfterAttack = !config.switchBackAfterAttack;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        stunningButton = method_37063(class_4185.method_46430(stunningText(), button -> {
            config.stunning = !config.stunning;
            if (!config.stunning) {
                config.stunWeb = ShieldHelperConfig.StunWebMode.OFF;
            }
            ShieldHelperConfig.save();
            buildWidgets();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        if (config.stunning) {
            missChanceButton = method_37063(class_4185.method_46430(missChanceText(), button -> {
                config.cycleMissChance();
                ShieldHelperConfig.save();
                updateButtonLabels();
            }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
            offset++;

            stunWebButton = method_37063(class_4185.method_46430(stunWebText(), button -> {
                config.stunWeb = config.stunWeb == ShieldHelperConfig.StunWebMode.ON ? ShieldHelperConfig.StunWebMode.OFF : ShieldHelperConfig.StunWebMode.ON;
                ShieldHelperConfig.save();
                updateButtonLabels();
            }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
            offset++;
        }

        cooldownRequirementButton = method_37063(class_4185.method_46430(cooldownRequirementText(), button -> {
            config.requireAttackCooldown = !config.requireAttackCooldown;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        attackStrengthButton = method_37063(class_4185.method_46430(attackStrengthText(), button -> {
            config.cycleMinimumAttackStrength();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        triggerCooldownButton = method_37063(class_4185.method_46430(triggerCooldownText(), button -> {
            config.cycleAttackCooldownTicks();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        postAttackGuardButton = method_37063(class_4185.method_46430(postAttackGuardText(), button -> {
            config.postAttackGuard = !config.postAttackGuard;
            ShieldHelperConfig.save();
            buildWidgets();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        if (config.postAttackGuard) {
            postAttackGuardTicksButton = method_37063(class_4185.method_46430(postAttackGuardTicksText(), button -> {
                config.cyclePostAttackGuardTicks();
                ShieldHelperConfig.save();
                updateButtonLabels();
            }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
            offset++;
        }

        blatantModeButton = method_37063(class_4185.method_46430(blatantModeText(), button -> {
            config.cycleBlatantMode();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
    }

    private void addControlControls(int x, int y) {
        int offset = 0;

        enabledButton = method_37063(class_4185.method_46430(enabledText(), button -> {
            config.enabled = !config.enabled;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        hotkeyToggleButton = method_37063(class_4185.method_46430(hotkeyToggleText(), button -> {
            config.hotkeyToggleEnabled = !config.hotkeyToggleEnabled;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        statusNotificationsButton = method_37063(class_4185.method_46430(statusNotificationsText(), button -> {
            config.statusNotifications = !config.statusNotifications;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        toggleKeyButton = method_37063(class_4185.method_46430(toggleKeyText(), button -> {
            waitingForToggleKey = true;
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        safetyModeButton = method_37063(class_4185.method_46430(safetyModeText(), button -> {
            config.cycleServerSafetyMode();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        safetyStatusButton = method_37063(class_4185.method_46430(safetyStatusText(), button -> {
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        safetyStatusButton.field_22763 = false;
        offset++;

        trustedServerButton = method_37063(class_4185.method_46430(trustedServerText(), button -> {
            String address = ShieldHelperSafety.getCurrentServerAddress(this.field_22787);
            if (!address.isEmpty()) {
                config.toggleTrustedServer(address);
                ShieldHelperConfig.save();
                updateButtonLabels();
            }
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        trustedServerButton.field_22763 = ShieldHelperSafety.canTrustCurrentServer(this.field_22787);
        offset++;

        pingCompensationButton = method_37063(class_4185.method_46430(pingCompensationText(), button -> {
            config.pingCompensation = !config.pingCompensation;
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
        offset++;

        maxAttackRangeButton = method_37063(class_4185.method_46430(maxAttackRangeText(), button -> {
            config.cycleMaxAttackRange();
            ShieldHelperConfig.save();
            updateButtonLabels();
        }).method_46434(x, y + CONTROL_SPACING * offset, CONTROL_WIDTH, CONTROL_HEIGHT).method_46431());
    }

    private void addDelayControls(int x, int y) {
        swapDelaySlider = method_37063(new DelaySliderButton(
                x,
                y,
                "shield-helper.config.swap_delay",
                () -> config.swapDelayMillis,
                value -> config.swapDelayMillis = value
        ));

        firstAttackDelaySlider = method_37063(new DelaySliderButton(
                x,
                y + CONTROL_SPACING,
                "shield-helper.config.first_attack_delay",
                () -> config.firstAttackDelayMillis,
                value -> config.firstAttackDelayMillis = value
        ));

        stunningMinDelaySlider = method_37063(new DelaySliderButton(
                x,
                y + CONTROL_SPACING * 2,
                "shield-helper.config.stunning_min_delay",
                () -> config.stunningMinDelayMillis,
                value -> config.stunningMinDelayMillis = value
        ));

        stunningMaxDelaySlider = method_37063(new DelaySliderButton(
                x,
                y + CONTROL_SPACING * 3,
                "shield-helper.config.stunning_max_delay",
                () -> config.stunningMaxDelayMillis,
                value -> config.stunningMaxDelayMillis = value
        ));

        int nextOffset = 4;
        if (config.stunning && config.stunWeb != ShieldHelperConfig.StunWebMode.OFF) {
            stunWebDelaySlider = method_37063(new DelaySliderButton(
                    x,
                    y + CONTROL_SPACING * nextOffset,
                    "shield-helper.config.stun_web_delay",
                    () -> config.stunWebDelayMillis,
                    value -> config.stunWebDelayMillis = value
            ));
            nextOffset++;
        }

        switchBackDelaySlider = method_37063(new DelaySliderButton(
                x,
                y + CONTROL_SPACING * nextOffset,
                "shield-helper.config.switch_back_delay",
                () -> config.switchBackDelayMillis,
                value -> config.switchBackDelayMillis = value
        ));
    }

    private void updateButtonLabels() {
        if (generalPageButton != null) {
            generalPageButton.method_25355(generalPageText());
        }
        if (controlsPageButton != null) {
            controlsPageButton.method_25355(controlsPageText());
        }
        if (delaysPageButton != null) {
            delaysPageButton.method_25355(delaysPageText());
        }
        if (profileButton != null) {
            profileButton.method_25355(profileText());
        }

        if (enabledButton != null) {
            enabledButton.method_25355(enabledText());
        }
        if (hotkeyToggleButton != null) {
            hotkeyToggleButton.method_25355(hotkeyToggleText());
        }
        if (statusNotificationsButton != null) {
            statusNotificationsButton.method_25355(statusNotificationsText());
        }
        if (toggleKeyButton != null) {
            toggleKeyButton.method_25355(toggleKeyText());
        }
        if (safetyModeButton != null) {
            safetyModeButton.method_25355(safetyModeText());
        }
        if (safetyStatusButton != null) {
            safetyStatusButton.method_25355(safetyStatusText());
        }
        if (trustedServerButton != null) {
            trustedServerButton.method_25355(trustedServerText());
        }
        if (switchBackButton != null) {
            switchBackButton.method_25355(switchBackText());
        }
        if (stunningButton != null) {
            stunningButton.method_25355(stunningText());
        }
        if (missChanceButton != null) {
            missChanceButton.method_25355(missChanceText());
        }
        if (shieldMissChanceButton != null) {
            shieldMissChanceButton.method_25355(shieldMissChanceText());
        }
        if (stunWebButton != null) {
            stunWebButton.method_25355(stunWebText());
        }
        if (cooldownRequirementButton != null) {
            cooldownRequirementButton.method_25355(cooldownRequirementText());
        }
        if (attackStrengthButton != null) {
            attackStrengthButton.method_25355(attackStrengthText());
        }
        if (triggerCooldownButton != null) {
            triggerCooldownButton.method_25355(triggerCooldownText());
        }
        if (pingCompensationButton != null) {
            pingCompensationButton.method_25355(pingCompensationText());
        }
        if (maxAttackRangeButton != null) {
            maxAttackRangeButton.method_25355(maxAttackRangeText());
        }
        if (postAttackGuardButton != null) {
            postAttackGuardButton.method_25355(postAttackGuardText());
        }
        if (postAttackGuardTicksButton != null) {
            postAttackGuardTicksButton.method_25355(postAttackGuardTicksText());
        }
        if (blatantModeButton != null) {
            blatantModeButton.method_25355(blatantModeText());
        }
    }

    private class_2561 generalPageText() {
        return pageText(PAGE_GENERAL, "shield-helper.config.page.general");
    }

    private class_2561 controlsPageText() {
        return pageText(PAGE_CONTROLS, "shield-helper.config.page.controls");
    }

    private class_2561 delaysPageText() {
        return pageText(PAGE_DELAYS, "shield-helper.config.page.delays");
    }

    private class_2561 pageText(int targetPage, String translationKey) {
        return class_2561.method_43471(page == targetPage ? translationKey + ".selected" : translationKey);
    }

    private class_2561 profileText() {
        return class_2561.method_43469("shield-helper.config.profile", profileValueText());
    }

    private class_2561 profileValueText() {
        return class_2561.method_43471(ShieldHelperConfig.PROFILE_SMP.equals(config.combatProfile)
                ? "shield-helper.config.profile.smp"
                : "shield-helper.config.profile.diasmp");
    }



    private class_2561 enabledText() {
        return class_2561.method_43469("shield-helper.config.macro", stateText(config.enabled));
    }

    private class_2561 hotkeyToggleText() {
        return class_2561.method_43469("shield-helper.config.hotkey_toggle", stateText(config.hotkeyToggleEnabled));
    }

    private class_2561 statusNotificationsText() {
        return class_2561.method_43469("shield-helper.config.status_notifications", stateText(config.statusNotifications));
    }

    private class_2561 toggleKeyText() {
        if (waitingForToggleKey) {
            return class_2561.method_43471("shield-helper.config.toggle_key.waiting");
        }

        return class_2561.method_43469("shield-helper.config.toggle_key", class_2561.method_43470(config.toggleKeyName.toUpperCase()));
    }

    private class_2561 safetyModeText() {
        return class_2561.method_43469("shield-helper.config.safety_mode", safetyModeValueText());
    }

    private class_2561 safetyModeValueText() {
        return class_2561.method_43471(ShieldHelperConfig.SAFETY_TRUSTED_SERVERS.equals(config.serverSafetyMode)
                ? "shield-helper.config.safety_mode.trusted_servers"
                : "shield-helper.config.safety_mode.all_worlds");
    }

    private class_2561 safetyStatusText() {
        return class_2561.method_43469("shield-helper.config.safety_status", safetyStatusValueText());
    }

    private class_2561 safetyStatusValueText() {
        return class_2561.method_43471(ShieldHelperSafety.isActionAllowed(this.field_22787, config)
                ? "shield-helper.config.safety_status.allowed"
                : "shield-helper.config.safety_status.blocked");
    }

    private class_2561 trustedServerText() {
        return class_2561.method_43469("shield-helper.config.trusted_server", trustedServerValueText());
    }

    private class_2561 trustedServerValueText() {
        if (!ShieldHelperSafety.canTrustCurrentServer(this.field_22787)) {
            return class_2561.method_43471("shield-helper.config.trusted_server.unavailable");
        }

        return stateText(config.isTrustedServer(ShieldHelperSafety.getCurrentServerAddress(this.field_22787)));
    }

    private class_2561 switchBackText() {
        return class_2561.method_43469("shield-helper.config.switch_back", stateText(config.switchBackAfterAttack));
    }

    private class_2561 stunningText() {
        return class_2561.method_43469("shield-helper.config.stunning", stateText(config.stunning));
    }

    private class_2561 missChanceText() {
        if (config.missChancePercent <= 0) {
            return class_2561.method_43469("shield-helper.config.miss_chance", class_2561.method_43471("gui.no"));
        }
        return class_2561.method_43469("shield-helper.config.miss_chance", class_2561.method_43470(config.missChancePercent + "%"));
    }

    private class_2561 shieldMissChanceText() {
        if (config.shieldMissChancePercent <= 0) {
            return class_2561.method_43469("shield-helper.config.shield_miss_chance", class_2561.method_43471("gui.no"));
        }
        return class_2561.method_43469("shield-helper.config.shield_miss_chance", class_2561.method_43470(config.shieldMissChancePercent + "%"));
    }

    private class_2561 stunWebText() {
        return class_2561.method_43469("shield-helper.config.stun_web", stateText(config.stunWeb == ShieldHelperConfig.StunWebMode.ON));
    }

    private class_2561 cooldownRequirementText() {
        return class_2561.method_43469("shield-helper.config.require_cooldown", stateText(config.requireAttackCooldown));
    }

    private class_2561 attackStrengthText() {
        return class_2561.method_43469("shield-helper.config.attack_strength", class_2561.method_43470(config.minimumAttackStrengthPercent + "%"));
    }

    private class_2561 triggerCooldownText() {
        return class_2561.method_43469("shield-helper.config.trigger_cooldown", class_2561.method_43470(config.attackCooldownTicks + " ticks"));
    }

    private class_2561 pingCompensationText() {
        return class_2561.method_43469("shield-helper.config.ping_compensation", stateText(config.pingCompensation));
    }

    private class_2561 maxAttackRangeText() {
        return class_2561.method_43469("shield-helper.config.max_attack_range", class_2561.method_43470(String.format(java.util.Locale.US, "%.1f blocks", config.maxAttackRange)));
    }

    private class_2561 postAttackGuardText() {
        return class_2561.method_43469("shield-helper.config.post_attack_guard", stateText(config.postAttackGuard));
    }

    private class_2561 postAttackGuardTicksText() {
        return class_2561.method_43469("shield-helper.config.post_attack_guard_ticks", class_2561.method_43470(config.postAttackGuardTicks + " ticks"));
    }

    private class_2561 blatantModeText() {
        return class_2561.method_43469("shield-helper.config.blatant_mode", stateText(config.blatantMode));
    }

    private static class_2561 stateText(boolean enabled) {
        return class_2561.method_43471(enabled ? "gui.yes" : "gui.no");
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (waitingForToggleKey) {
            int keyCode = event.comp_4795();
            if (keyCode == class_3675.field_31958) {
                waitingForToggleKey = false;
            } else {
                config.toggleKeyCode = keyCode;
                config.toggleKeyName = class_3675.method_15985(event).method_1441();
                ShieldHelperConfig.save();
                waitingForToggleKey = false;
            }

            updateButtonLabels();
            return true;
        }

        return super.method_25404(event);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);

        int x = (this.field_22789 - CONTROL_WIDTH) / 2;
        int bottomY = this.field_22790 - 48;
        graphics.method_27534(this.field_22793, successRateText(), this.field_22789 / 2, bottomY, 0xAAAAAA);
    }

    private class_2561 successRateText() {
        if (config.shieldDisableAttempts <= 0L) {
            return class_2561.method_43471("shield-helper.config.success_rate.empty");
        }

        return class_2561.method_43469("shield-helper.config.success_rate",
                config.getShieldDisableSuccessPercent(), config.shieldDisableSuccesses, config.shieldDisableAttempts);
    }

    private static final class DelaySliderButton extends class_357 {
        private final String translationKey;
        private final IntSupplier getter;
        private final IntConsumer setter;

        private DelaySliderButton(int x, int y, String translationKey, IntSupplier getter, IntConsumer setter) {
            super(x, y, CONTROL_WIDTH, CONTROL_HEIGHT, class_2561.method_43473(), valueToSlider(getter.getAsInt()));
            this.translationKey = translationKey;
            this.getter = getter;
            this.setter = setter;
            method_25346();
        }

        @Override
        protected void method_25346() {
            method_25355(class_2561.method_43469(translationKey, sliderToValue(this.field_22753)));
        }

        @Override
        protected void method_25344() {
            setter.accept(sliderToValue(this.field_22753));
            ShieldHelperConfig.save();
        }

        private static int sliderToValue(double value) {
            int valueMillis = (int) Math.round(value * DELAY_MAX_MILLIS);
            return (valueMillis / DELAY_STEP_MILLIS) * DELAY_STEP_MILLIS;
        }

        private static double valueToSlider(int valueMillis) {
            if (valueMillis <= 0) {
                return 0.0D;
            }

            return Math.min(valueMillis, DELAY_MAX_MILLIS) / (double) DELAY_MAX_MILLIS;
        }
    }
}

package com.example.shieldhelper.client;

import com.example.shieldhelper.config.ShieldHelperConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_642;

@Environment(EnvType.CLIENT)
public final class ShieldHelperSafety {
    private ShieldHelperSafety() {
    }

    public static boolean isActionAllowed(class_310 client, ShieldHelperConfig config) {
        if (client == null || client.field_1687 == null) {
            return false;
        }

        if (isSingleplayerOrLan(client)) {
            return true;
        }

        return ShieldHelperConfig.SAFETY_TRUSTED_SERVERS.equals(config.serverSafetyMode)
                && config.isTrustedServer(getCurrentServerAddress(client));
    }

    public static boolean isSingleplayerOrLan(class_310 client) {
        if (client == null) {
            return false;
        }

        class_642 serverData = client.method_1558();
        return client.method_1542() || serverData != null && serverData.method_2994();
    }

    public static boolean canTrustCurrentServer(class_310 client) {
        return !isSingleplayerOrLan(client) && !getCurrentServerAddress(client).isEmpty();
    }

    public static String getCurrentServerAddress(class_310 client) {
        if (client == null) {
            return "";
        }

        class_642 serverData = client.method_1558();
        if (serverData == null || serverData.field_3761 == null) {
            return "";
        }

        return ShieldHelperConfig.normalizeServerAddress(serverData.field_3761);
    }
}
